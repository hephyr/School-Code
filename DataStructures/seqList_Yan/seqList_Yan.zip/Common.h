//
//  Common.h
//  seqList
//
//  Created by Zephyr on 15/10/4.
//  Copyright © 2015年 Zephyr. All rights reserved.
//

#ifndef COMMON_H
#define COMMON_H

#define TRUE	    1
#define FALSE		0
#define OK			1
#define ERROR		0
#define INFEASIBLE  -1
#define OVERFLOW	-2

typedef int Status;

#endif //COMMON_H